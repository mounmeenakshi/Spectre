#I am grateful to Soumya Roy for helping me with the data structure(local dictionaries here) I required to store halo information in this code. Also I thank Partha Deka for discussing few issues I encountered while writing the code.

import time as tot_time
start = tot_time.time()
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import quad
from scipy.interpolate import NearestNDInterpolator as intp
from bah import Behroozi_2013a 
aa= Behroozi_2013a()
import os,fnmatch

m_stellar=[] # list to store the stellar mass for a particular redshift(z=0 here)
m_str=[]  # list for the stellar mass of all the halos in the tree
m_halo=[]  #list to store the halo mass for a particular redshift(z=0 here)
m_icl=[] #list for icl for a particular redshift(z=0 here)
sSFR=[] # list for sSFR for all the halos in the tree
scale_f=[]#list for scale factor for halos at z=0
files_dir = '/home/meenakshi/Downloads/Stud9'  #location for tree files
fi=0
for file_n in os.listdir(files_dir):
    fi =fi+1

    if fnmatch.fnmatch(file_n, "tree_*"):
        with open(os.path.join(files_dir,file_n)) as f:
            a,num_prog,mvir= np.loadtxt(f,usecols=(0,1,3),unpack=True)
                            

    n=0
    for i in range(len(a)-1):    
        if (a[i] >= 1.0/6.0):    #extracting halos till redshift of 5 
            n=n+1


    a_array=[]

    a = a[:n]

    num_prog=num_prog[:n]   #array for number of progenitors
    mvir=mvir[:n]          #array for virial mass
    n=n-1
      

#Assigning indices in dictionary for each halo (H_0, H_1,..so on)
    for i in range(n+1):
        locals()["H_"+str(i)] ={}  #I thank Soumya here for teaching me how to define local dictionaries for each halo
        locals()["H_"+str(i)]['m'] =mvir[i]
        locals()["H_"+str(i)]['a']=a[i]
        locals()["H_"+str(i)]['np']=num_prog[i]



    i=n
    locals()["H_"+str(i)]['np']=0      #assigning number of progenitors zero for the last halo
# Making num_prog =0 for last halo at z=5
    while(True):
        if (a[i]==a[i-1]):
            locals()["H_"+str(i-1)]['np']=0  #assigning number of progenitors zero for the last redshift (here z=5)
            i=i-1
        else:
            break

# finding parent ids p-id	
    j=0; p=1
    for j in range(n+1):
        k=0
        t=int(locals()["H_"+str(j)]['np'])
        if (t==0):
            locals()["H_"+str(j)]['p-id']=0
        else:	
            arr=np.zeros(t)
            for k in range(t):
                arr[k]=p  #making an array of who the parents are for a halo
                p=p+1 
                k+=1     
                locals()["H_"+str(j)]['p-id']= arr     #Entering the parents id in child halos dictionary label 'p-id'
        j=j+1

	#print (H_0, H_1, H_2)
	
    h_0 =73.5e-12
    omega_m = 0.321
    omega_L =0.6789
    omega_r = 10**(-4)
    omega_k = 1 - omega_m - omega_L - omega_r

    def func(a):	  #function to calculate time between two scale factors(for Lambda- CDM model)
        I = 1/(h_0*a*np.sqrt(omega_m * a**(-3) + omega_L + omega_r* a**(-4)  + omega_k *a**(-2)))
        return I

    i=n
    k=0
    m=True
    while(m):  #calcualting number of halos in the last scale factor
        if (a[i] == a[i-1]):
            i=i-1
            k=k+1
        else:
            k=k+1
            m=False



    t=n  #the last row of halos  (TOTAL HALOS ARE 0-n i.e. (n+1))



    for i in range(k):  #(0 to k-1)  #last halos assigning stellar mass and setting icl component to zero
        locals()["H_"+str(t)]['mstr']=10**(aa.SHMRbeh(np.log10(locals()["H_"+str(t)]['m']),(1/locals()["H_"+str(t)]['a'])-1))
        locals()["H_"+str(t)]['icl']=0
        t=t-1


    f1 =np.loadtxt("sfe.dat")        #to find dM*/dMh
    z_1 = (f1[:,0])
    log_mh = (f1[:,1])
    log_sfr = (f1[:,2])
    c = np.vstack((z_1,log_mh)).T


    near = intp(c, log_sfr)  #making 2-D array of log(halo mass) and redhsift for 2-D interpolation


    sec_halo = t  #2nd scale factor halos from the last 
     #denotes dm*/dt = dm*/dmh * dmh/dt
# array for dM*/dt from parents to kids (only derivative part)
    for t in range(n+1):
        if (locals()["H_"+str(t)]['np'] == 0.0):  #assiging the stellar mass from behroozi function for no halos with no progenittors
            locals()["H_"+str(t)]['mstr']=10**(aa.SHMRbeh(np.log10(locals()["H_"+str(t)]['m']),(1/locals()["H_"+str(t)]['a'])-1)) 
            locals()["H_"+str(t)]['dm*/dt']=0
            locals()["H_"+str(t)]['icl'] = 0
        else:	
            lia=[]
            for i in locals()["H_"+str(t)]['p-id']:
                lia.append(locals()["H_"+str(int(i))]['m'])
            max_m = max(lia)  #halo with maximum mass among progenitors 
            time = quad(func,locals()["H_"+str(int(i))]['a'], locals()["H_"+str(int(t))]['a']) #calculating time between parents and kid halo
            value = near(1/(locals()["H_"+str(t)]['a']),np.log10(locals()["H_"+str(t)]['m'])) #nearest neighbour to find the star formation rate from given data set
            if (value == str('nan')):
                value = - float('inf')
            dm_dmh = 0.14*(10**value) #fb= omega_b/omega_m = 0.14
            dm_dt =dm_dmh*(locals()["H_"+str(int(t))]['m'] - max_m)/(time[0]) 
            if (locals()["H_"+str(int(t))]['m'] - max_m < 0):  #if halo mass change is negative from parents generation to child 
                dm_dt=0
            locals()["H_"+str(t)]['dm*/dt']=(dm_dt)   #putting dm*/dt in the dictionary of kids from their progenitors which will be passed on to grandchildren
          
            #print (dm_dt[t])


    t= sec_halo
    #print (t)
    for s in range(n+1-k):
        if (locals()["H_"+str(t)]['np']== 1.0) or (locals()["H_"+str(t)]['np']== 2.0): #for one or two progenitors
            tot_m = 0
            dm_dt =0
            tot_icl = 0
            for i in locals()["H_"+str(t)]['p-id']:
                tot_m = locals()["H_"+str(int(i))]['mstr']+tot_m
                tot_icl = locals()["H_"+str(int(i))]['icl']+tot_icl
                dm_dt = locals()["H_"+str(int(i))]['dm*/dt']+(10**np.random.normal(np.log10(10**(-12)*(locals()["H_"+str(int(i))]['mstr'])),0.25))+dm_dt
            time = quad(func,locals()["H_"+str(int(i))]['a'], locals()["H_"+str(int(t))]['a'])
            locals()["H_"+str(t)]['mstr'] = tot_m + dm_dt *(time[0])  #the stellar mass and produced mass of both the halos adds up 
            locals()["H_"+str(t)]['icl'] = tot_icl #icl from both is added and given child halo

        if (locals()["H_"+str(t)]['np'] > 2.0): #for more than 2 progenitors
            m_list=[]		
            dm_dt=0
            tot_icl =0
            for i in locals()["H_"+str(t)]['p-id']:
                time = quad(func,locals()["H_"+str(int(i))]['a'], locals()["H_"+str(int(t))]['a'])
                tot_icl = locals()["H_"+str(int(i))]['icl']+ locals()["H_"+str(int(i))]['mstr'] + (10**np.random.normal(np.log10(10**(-12)*locals()["H_"+str(int(i))]['mstr']),0.25)+ locals()["H_"+str(int(i))]['dm*/dt']) *(time[0])+tot_icl
                m_list.append(locals()["H_"+str(int(i))]['mstr'])
            max_m = max(m_list)  
            for i in locals()["H_"+str(t)]['p-id']:
                if (locals()["H_"+str(int(i))]['mstr'] == max_m):
                    dm_dt = locals()["H_"+str(int(i))]['dm*/dt']*(time[0])
            tot_icl = tot_icl - max_m -dm_dt
            locals()["H_"+str(t)]['mstr'] = max_m + dm_dt  #only massive halo gives the stellar mass to the child halo
            locals()["H_"+str(t)]['icl'] = tot_icl  #other halos mass and generated mass over time evolution goes to icl
             
        if (locals()["H_"+str(t)]['np'] == 0.0):  #for no progenitor
            locals()["H_"+str(t)]['mstr']=10**(aa.SHMRbeh(np.log10(locals()["H_"+str(t)]['m']),(1/locals()["H_"+str(t)]['a'])-1)) #mass is assigned from function given in Behroozi et.al 
            locals()["H_"+str(t)]['icl'] = 0
            
        #print ( locals()["H_"+str(t)])
        if (locals()["H_"+str(t)]['a'] == 1):  #saving in lists stellar mass, halo mass and icl for z=0 halos only in each tree
            m_stellar.append(locals()["H_"+str(t)]['mstr'])
            m_halo.append(locals()["H_"+str(t)]['m'])
            m_icl.append(locals()["H_"+str(t)]['icl'])
            
	#saving in lists stellar mass and sSFR for all the halos 
        m_str.append(locals()["H_"+str(t)]['mstr'])
        sSFR.append(locals()["H_"+str(t)]['dm*/dt']+(10**np.random.normal(np.log10(10**(-12)*locals()["H_"+str(t)]['mstr']),0.25)))
        t=t-1  #decreasing halo index from high redshift to lower(z=0)

    print (fi,file_n ,'done')        



np.savetxt('data1.txt',np.c_[m_str,sSFR])
np.savetxt('data.txt', np.c_[m_halo,m_stellar,m_icl])

  
	
#plot for log(stellar mass + icl) and log(stellar mass) vs log(halo mass)

m_halo, m_stellar,m_icl=np.loadtxt('data.txt', unpack=True)
zz=0

Mhalo = np.linspace(9.0, 15.0, 100)
Mstel = aa.SHMRbeh(Mhalo, zz)
plt.plot(Mhalo, Mstel, label="z=%.1f" % zz)
plt.xlabel(r"$\log_{10} M_{\rm halo}$")
plt.ylabel(r"$\log_{10} M_*$")

p1=plt.scatter(np.log10(m_halo),np.log10(m_stellar+m_icl),s=12)
p2=plt.scatter(np.log10(m_halo),np.log10(m_stellar),s=12)

plt.legend((p1,p2),('$log_{10}(M*+M_{icl})$','$log_{10}(M*)$'))
plt.show() 

end=tot_time.time()
print(start-end)  #time taken to run the code (seconds)

