#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Feb 20 12:18:47 2020

@author: mounmeenakshi
"""
#from halo4
import time as tot_time
start = tot_time.time()
import numpy as np
import matplotlib.pyplot as plt




#histogram plot for  log(sSFR/yr) vs number of galaxies
m_str,sSFR=np.loadtxt('data1.txt', unpack=True)
m_s=[]
total = len(m_str)

for i in range(total):
    if ((np.log10(m_str[i]) > 10.5)):
        m_s.append(np.log10(sSFR[i]/m_str[i]))
        
        
    
weights = np.ones_like(m_s)/float(len(m_s))
plt.title('$log_{10}(M_*)>10.5$')
plt.xlabel(r"$log_{10}[ssFR/yr^{-1}]$")
plt.ylabel("fraction of galaxies")
plt.hist(m_s,weights=weights,bins=25,density =True)
plt.show() 

for i in range(total):
    if ((np.log10(m_str[i]) > 11.5)):
        m_s.append(np.log10(sSFR[i]/m_str[i]))
        
    
weights = np.ones_like(m_s)/float(len(m_s))
plt.title('$log_{10}(M_*)>11.5$')
plt.xlabel(r"$log_{10}[ssFR/yr^{-1}]$")
plt.ylabel("fraction of galaxies")
plt.hist(m_s,weights=weights,bins=25,density =True)
plt.show() 
