import numpy as np
import matplotlib.pyplot as pl

class Behroozi_2013a:
    def __init__(self):
        self.eps0=-1.777;
        self.epsa=-0.006;
        self.epsz=-0.000;
        self.epsa2=-0.119;

        self.xM10=11.514;
        self.xM1a=-1.793;
        self.xM1z=-0.251;

        self.alp0=1.412;
        self.alpa=-0.731;

        self.delta0=3.508;
        self.deltaa=2.608;
        self.deltaz=-0.043;

        self.gamma0=0.316;
        self.gammaa=1.319;
        self.gammaz=0.279;


    def evolved_factors(self,zz):
        a=1./(1.+zz);
        nu=np.exp(-4*a*a);
        alp=self.alp0+self.alpa*(a-1.0)*nu;
        delta=self.delta0+(self.deltaa*(a-1.)+self.deltaz*zz)*nu;
        gamma=self.gamma0+(self.gammaa*(a-1.)+self.gammaz*zz)*nu;
        eps=self.eps0+(self.epsa*(a-1.0)+self.epsz*zz)*nu+self.epsa2*(a-1.)
        xM1=self.xM10+(self.xM1a*(a-1.0)+self.xM1z*zz)*nu;
        return nu, alp, delta, gamma, eps, xM1

    def fbeh12(self, x, nu, alp, delta, gamma):
        return -np.log10(10.**(-alp*x)+1)+delta*(np.log10(1.+np.exp(x)))**gamma/( 1. + np.exp(10.**-x) )

    def SHMRbeh(self, xmh,zz):
        nu, alp, delta, gamma, eps, xM1 = self.evolved_factors(zz)
        xmstel=eps+xM1+self.fbeh12(xmh-xM1, nu, alp, delta, gamma)-self.fbeh12(0.0, nu, alp, delta, gamma);
        return xmstel;
'''
aa = Behroozi_2013a()
Mhalo = np.linspace(9.0, 15.0, 100)

ax = pl.subplot(111)
zz=0
#for zz in [0.1, 1.0, 2.0, 3.0, 4.0, 5.0]:
Mstel = aa.SHMRbeh(Mhalo, zz)
ax.plot(Mhalo, Mstel, label="z=%.1f" % zz)

ax.set_xlim(10.0, 15.0)
ax.set_ylim(7.0, 12.0)
ax.set_xlabel(r"$\log_{10} M_{\rm halo}$ ($h_{70}^{-1}M_\odot$)")
ax.set_ylabel(r"$\log_{10} M_*$ ($h_{70}^{-2}M_\odot$)")
pl.legend()'''