

The code files are : bah.py, halo.py, halo1.py

halo.py is the main code file and bah.py defines a function to give stellar mass to the orphan halos(halos with no progenitors).
The data file to find the star formation efficiency is 'sfe.dat'
Keep all these files in the same folder. The directory for the tree files are given in the variable files_dir(which is '/home/meenakshi/Downloads/meenakshi_project/Stud9' and needs to be modified before running the code). The code can be run in sypder or using-  python3 halo.py command in terminal.
The whole code(using Stud9 data) takes around 940 seconds to run .(Enjoy a break in the mean time! :P)


In the code an id is assigned to each halo starting from z=0 which has id 0(name H_0) and so for ith halo id is i+1 and name H_i+1.
halo.py on execution gives the dictionary of all the halos at a redshift containing halo mass, scale factor(a), no. of progenitors(np),  progenitor halos id(p-id), mass rate from parents(dm*/dt), stellar mass(mstr), Inter cluster light (icl).

A text file data.txt is created in the directory containing halo mass, stellar mass, icl, star formation rate(m_halo,m_stellar,m_icl,sSFR) for each halo at the given redshift(z=0 here).
Also it creates a txt file named data1.txt and save stellar mass and specific star formation rate(m_stellar,sSFR) for all the halos in the tree.


Then it uses data.txt and gives log-log plot of halo mass and stellar plus icl mass for each halo along with halo mass and stellar mass log-plot as above.(as shown in Figure 1 of Becker 2015)

halo1.py uses data1.txt and creates a histogram of the no. of galaxies vs log(sSFR/yr) as shown in Figure 2 of Becker 2015. The number of galaxies with log(sSFR/yr) follows bimodular distribution at low values of log(stellar mass) and begins converge to around -11.3 as one checks for high stellar mass halos(log(stellar mass)> 11.5 here). 




